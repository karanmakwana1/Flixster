//
//  ViewController.swift
//  Flixster
//
//  Created by Karan Makwana on 12/06/20.
//  Copyright © 2020 karanmakwana1. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

